<h1 class="tex-head mb-2"> Añadir Nueva Categoria</h1>
<form action="<?php echo e(route('add.categoria')); ?>" method="POST" enctype = "multipart/form-data">
	<?php echo csrf_field(); ?>

	<div class="form-group row">
		<label for="category" class="col-sm-2 col-form-label">Nombre  categoria </label>
		<div class="col-sm-10">
			<input type="text" name="name" class="form-control">
		</div>
	</div>
	<div class="form-group row">
		<label for="category" class="col-sm-2 col-form-label">Categoria superior </label>
		<div class="col-sm-10">
		<select class="form-control" name="categorie">
			<option value="null">Sin categoria superior</option>
			<?php echo $__env->make('admin.category-show',array('ParentsCategory' => $ParentsCategory), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</select>
		
		</div>
	</div>
	<div class="form-group row" >
		<label for="pic" class="col-sm-2 col-form-label">Image(Solo categoria superior)</label>
		<div class="col-sm-10">
			<input type="file" name="pic" class="form-control" id="pic">
		</div>
	</div>
	<div class="d-flex mt-4">
		<input type="submit" name="bb" class="btn btn-cyan rounded-pil mr-auto" >

	</div>

</form>
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/admin/categorie.blade.php ENDPATH**/ ?>