<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
        
        <script src="https://kit.fontawesome.com/fd8d177af3.js" crossorigin="anonymous"></script>
 
  </head>
<body>  

        
     
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container container-height mt-5 p-5">
  <h1 class="text-head">Pedido <?php echo e($order->id); ?>:</h1>
  <h2 class="mt-2">Datos del cliente:</h2>
  <p>Nombre:<strong class="ml-2"><?php echo e($order->Name); ?></strong></p>
  <p>Apellido:<strong class="ml-2"><?php echo e($order->Lastname); ?></strong></p>
  <p>Cedula:<strong class="ml-2"><?php echo e($order->Cedula[0]); ?>*******</strong></p>
  <p>Estado:<strong class="ml-2"><?php echo e($order->Estado); ?></strong></p>
  <p>Ciudad:<strong class="ml-2"><?php echo e($order->city); ?></strong></p>
  <p>Telefono:<strong class="ml-2"><?php echo e($order->phone[0]); ?>*******</strong></p>
  <p>Correo:<strong class="ml-2"><?php echo e($order->email[0]); ?>*******</strong></p>
  <p>Metodo de envio:<strong class="ml-2"><?php echo e($order->delivery); ?></strong></p>
  <p>Metodo de pago:<strong class="ml-2"><?php echo e($order->payment); ?></strong></p>
  <h2 class="mt-2">Productos del pedido <?php echo e($order->id); ?>:</h2>
  <?php ($total = 0.0); ?>

  <p class="mt-2">Por Favor seleccione los productos que desea conservar.</p>
<form action="<?php echo e(route('check.order.sub')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
  <ul style="list-style: none;">
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <li>

        <div class="custom-control custom-checkbox">
          <input type="checkbox" class="custom-control-input" name="is_ok[]" id="<?php echo e('customCheck'.$loop->iteration); ?>" value="<?php echo e($product->id); ?>">
          <label class="custom-control-label" for="<?php echo e('customCheck'.$loop->iteration); ?>"> </label>
        </div>
        <ul style="list-style: none">
          <li>
            <span>Producto:
            <strong class="ml-2 " ><a href="<?php echo e(route('product.show',Str::slug($product->tittle,'-') )); ?>"><?php echo e($product->tittle); ?></a></strong></span> 
            <img src="<?php echo e(asset('storage/'.$product->pic)); ?>" width="50px" height="50px">
          </li>

          <li>
            <span>Precio: <?php echo e($product->price); ?>$</span>
          </li>

          <li >
            <span>Cantidad: <?php echo e($product->quantity); ?> </span> <input type="number" min="1" max="10" name="is_q[]" class="ml-2 " value="1">
          </li>

          <li>
            <span>Subtotal: <?php echo e($product->price * $product->quantity); ?>$</span>
          </li>
      </ul>
    </li>
    <?php ($total = $total + ($product->price * $product->quantity)  ); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  <p>Total: <?php echo e($total); ?>$</p>
<input type="submit" value="continuar"  class="btn btn-danger">
</form>

</div>





 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/order/check.blade.php ENDPATH**/ ?>