<?php $__currentLoopData = $ParentsCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ParentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if(isset($c)): ?>
    	<option value="<?php echo e($ParentCategory->id); ?>">-->  <?php echo e($ParentCategory->Name); ?></option>
    <?php else: ?>
    	<option value="<?php echo e($ParentCategory->id); ?>"><?php echo e($ParentCategory->Name); ?> (P)</option>
	<?php endif; ?>
    <?php if($ParentCategory->children != null): ?>
    	<?php echo $__env->make('admin.category-show',array('ParentsCategory' => $ParentCategory->children,'c' => true), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/admin/category-show.blade.php ENDPATH**/ ?>