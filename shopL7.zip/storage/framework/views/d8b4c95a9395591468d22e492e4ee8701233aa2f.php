<div>
<?php if(isset($contacts)): ?>
	<ul>
	<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><span><?php echo e($contact->name); ?> --> </span><span> <?php echo e($contact->email); ?></span>
			<ul>
				<li><?php echo e($contact->msg); ?></li>
			</ul>
		</li>
			
		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	
<?php endif; ?>
</div><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/admin/contact.blade.php ENDPATH**/ ?>