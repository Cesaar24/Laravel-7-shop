<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/app.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/fontawesome.min.css">
        <script src="https://kit.fontawesome.com/fd8d177af3.js" crossorigin="anonymous"></script>
 
  </head>
<body>  

      

  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="container container-height">
     
    <div class=" mt-5 pt-5 ">
    <?php ($count = count($products)); ?>	
    	<?php if(count($products) > 0): ?>
			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($count <= 2): ?>
					<?php if($loop->first): ?>
					<div class="row mt-5 p-5">
					<?php endif; ?>
						<div class="col-sm-6 p-2 text-center">
              <a href="<?php echo e(route('product.show',Str::slug($parent->tittle,'-'))); ?>">
  							<img src="<?php echo e(asset('storage/'.$parent->pic)); ?>" width="240" height="200">
  						  <p><?php echo e($parent->tittle); ?></p>
              </a>
						</div>
					<?php if($loop->last): ?>
					</div>
					<?php endif; ?>
				<?php else: ?>
					<?php if($loop->first or ($loop->iteration % 3) == 1): ?>
					<div class="row mt-5 p-5">
					<?php endif; ?>
						<div class="col-sm-4 text-center p-2">
						
            <a href="<?php echo e(route('product.show',Str::slug($parent->tittle,'-') )); ?>">
						<img src="<?php echo e(asset('default.png')); ?>" width="240" height="200">
						  <p><?php echo e($parent->tittle); ?></p>
            </a>
						
					</div>
					<?php if( ($loop->iteration % 3) == 0 or ($loop->last)): ?>	
					</div>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        	<h1 class=" text-head">Productos no encontrado</h1>
        <?php endif; ?>

    </div>
    

  </div>


<?php if(session('status')): ?>
  <div class="toast toast-status position-fixed bottom-0 right-0 " role="alert" aria-live="assertive" aria-atomic="true" data-delay="5000" >
    <div class="toast-header ">
      
      <i class="fas fa-check mr-auto"></i>
      <button type="button" class=" mb-1 close" data-dismiss="toast" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="toast-body">
     <?php echo e(session('status')); ?>

    </div>
  </div>
<?php endif; ?>


 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
<script type="text/javascript" src="js/app.js"></script>
<script type="text/javascript">
  $('.toast').toast('show');
</script>
</body>
</html>
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/search.blade.php ENDPATH**/ ?>