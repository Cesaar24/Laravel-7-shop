<div id="carouselExampleControls" class="carousel slide carousel-relateds" data-ride="carousel">
  <div class="carousel-inner">



  <?php $__currentLoopData = $relateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
    <?php if($loop->first): ?>
      <div class="carousel-item active">
        <div class="row">
          <div class="col-sm-12 text-center product-slide">
            <a href="<?php echo e(route('product.show',Str::slug($related->tittle,'-') )); ?>">
            <img src="<?php echo e(asset('storage/'.$related->pic)); ?>"  alt="default.png">
            <p ><?php echo e($related->tittle); ?></p>
            <span><?php echo e($related->price); ?>$</span>
            </a>
          </div>
        </div>
      </div>
    <?php else: ?> 
      <div class="carousel-item">
        <div class="row">
          <div class="col-sm-12 text-center product-slide">
            <a href="<?php echo e(route('product.show',Str::slug($related->tittle,'-') )); ?>">
            <img src="<?php echo e(asset('storage/'.$related->pic)); ?>"  alt="default.png">
            <p ><?php echo e($related->tittle); ?></p>
            <span><?php echo e($related->price); ?>$</span>
            </a>
          </div>
        </div>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        

  </div>

  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/layouts/carrusel-category.blade.php ENDPATH**/ ?>