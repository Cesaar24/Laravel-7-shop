
	<?php $__currentLoopData = $ParentsCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ParentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><a href="#"><?php echo e($ParentCategory->Name); ?></a><a class="parent" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">+</a></li>

		<?php if($ParentCategory->children != null): ?>
			<div class="collapse" id="collapseExample">
				<ul class="child">
					<?php echo $__env->make('category.menu',array('ParentsCategory'=>$ParentCategory->children), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</ul>
			</div>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/category/menu.blade.php ENDPATH**/ ?>