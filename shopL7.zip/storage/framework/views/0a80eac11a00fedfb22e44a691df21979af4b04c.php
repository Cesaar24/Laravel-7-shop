<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
        
        <script src="https://kit.fontawesome.com/fd8d177af3.js" crossorigin="anonymous"></script>
 
  </head>
<body>  

        
     
         <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

         <div class="container container-height mt-5 p-5">
            <h1 class="text-head">Revise su pedido</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
            cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
            proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <form action="<?php echo e(route('check.order')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="id">Id de su pedido</label>
                <input type="text" name="id" class="form-control">
              </div>             
              <div class="form-group">
                <label for="id">Email</label>
                <input type="email" name="email" class="form-control">
              </div>
              <div class="form-group">
                <input type="submit" value = 'ver su pedido' class="btn btn-secondary">
              </div>
            </form>
         
         </div>
    
<?php if(session('status')): ?>
  <div class="toast toast-status position-fixed bottom-0 right-0 " role="alert" aria-live="assertive" aria-atomic="true" data-delay="5000" >
    <div class="toast-header ">
      
      <i class="fas fa-check mr-auto"></i>
      <button type="button" class=" mb-1 close" data-dismiss="toast" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="toast-body">
     <?php echo e(session('status')); ?>

    </div>
  </div>
<?php endif; ?>    


 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
<script type="text/javascript">
  $('.toast').toast('show');
</script>
</body>
</html>
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/order/form.blade.php ENDPATH**/ ?>