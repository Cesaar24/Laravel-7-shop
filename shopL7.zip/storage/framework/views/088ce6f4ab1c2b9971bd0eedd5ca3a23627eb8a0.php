<div class="mt-5 pt-3">
	<h1 class="text-center">Resumen de su compra</h1>
</div>
<div class="mt-1 ">

<table class="table mb-5">
	<thead class="thead-dark">
		<tr>
		  <th scope="col">#</th>
		  <th scope="col">Producto</th>
		  <th scope="col">Precio</th>
		  <th scope="col">Cantidad</th>
		  <th scope="col">Total</th>
		</tr>
	</thead>

	<tbody>

		<?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<th scope="row"><?php echo e($loop->iteration); ?></th>
				<td><a href="<?php echo e(route('product.remove',$item->id)); ?>" class="remove">X</a><a href="<?php echo e(route('product.show',Str::slug($item->name,'-'))); ?>"><?php echo e($item->name); ?></a> </td>
				<td><?php echo e($item->price); ?>$</td>
				<td><?php echo e($item->quantity); ?></td>
				<td><?php echo e($item->price * $item->quantity); ?>$</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<tr class="bg-info">
				<th scope="row" colspan="4" >Total </th>
				<td ><?php echo e(Cart::getTotal()); ?>$</td>
			</tr>
	</tbody>

</table>
<div class="d-flex justify-content-end mt-4">
	<a href="<?php echo e(route('check')); ?>" class="btn btn-danger rounded-pill">Realizar Pedido</a>
</div>
</div><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/cart/show.blade.php ENDPATH**/ ?>