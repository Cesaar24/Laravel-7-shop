
<div class="cart collapse " id="sidecart">
  

	<h3 class=" text-center">Carrito de Compra</h3>
	<?php if(!Cart::isEmpty()): ?>
		<ul>
			<?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="mt-3 pr-3">
					
						<div class="cardproduct " >
							<?php if(Request::route()->methods[0] != 'POST'): ?>
								<a href="<?php echo e(route('product.remove',$item->id)); ?>" class="remove">X</a>
							<?php endif; ?>
							<img src="<?php echo e(asset('storage/'.$item->attributes[0])); ?>" width="70px" height="70px" class="mx-auto">
							<div class="text-center">
								<a href="<?php echo e(route('product.show',Str::slug($item->name,'-'))); ?>"><p><?php echo e($item->name); ?></p></a>
								<p><?php echo e($item->quantity); ?>x<?php echo e($item->price); ?>$</p>	
							</div>
						</div>
					
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<div class="text-center">
			<p>Subtotal: <?php echo e(number_format(Cart::getSubtotal(),2)); ?>$</p>
		</div>
		<div class="mt-1">	
			<a href="<?php echo e(route('cart.show')); ?>" class="btn btn-cyan btn-block rounded-pill" >Ver Carrito</a>
			
		</div>
	<?php else: ?>	
		<p class="mt-3 text-center" style="font-size: 18px; font-family: Georgia;">Su Carrito Esta Vacio</p>
	<?php endif; ?>
	
</div>




<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/cart/resume.blade.php ENDPATH**/ ?>