<div id="carrusel-adds" class="carousel slide mt-5 pt-2" data-ride="carousel">
 




  <div class="carousel-inner">


    <div class="carousel-item active">
      <img src="computer-mouse.webp" class="d-block w-100" alt="..." >
      <div class="carousel-caption d-none d-md-block">
        <h4>¿Necesitas un mouse?</h4>
        <p>Consigue nuestros mejores mouse aqui.</p>
        <a href="categoria/mouse" class="btn btn-adds">Comprar ahora</a>
      </div>
    </div>



    <div class="carousel-item">
      <img src="elect.webp" class="d-block w-100" alt="..." >
      <div class="carousel-caption d-none d-md-block">
        <h4>¿Te gusta la electronica?</h4>
        <p>Seguro que necesitas esto</p>
        <a href="categoria/electronica" class="btn btn-adds">Ver ahora</a>
      </div>
    </div>



    <div class="carousel-item">
      <img src="keyboard.jpg" class="d-block w-100" alt="..." >
      <div class="carousel-caption last">
        <h4>Tecnologia</h4>
        <p>Some representative placeholder content for the third slide.</p>
        <a href="categoria/tecnologia" class="btn btn-adds">Ver ahora</a>
      </div>
    </div>
  </div>






  <a class="carousel-control-prev" href="#carrusel-adds" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carrusel-adds" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>



<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/layouts/carrusel-advertising.blade.php ENDPATH**/ ?>