
<nav class="sidebar">
  <div class="d-flex text"><span class="ml-1">Categorias</span> <a data-toggle="collapse" href="#index" class="parent ml-auto mr-2" id="head"> - </a></div>
  <div class="collapse"  id="index">
  	<ul >
    	
    	<?php echo $__env->renderEach('category.example',$ParentsCategory,'ParentCategory'); ?>
  	</ul>	
  </div>
  
</nav>

<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/category/slide.blade.php ENDPATH**/ ?>