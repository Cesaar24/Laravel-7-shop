



<div class="mt-5 p-5 d_flex justify-content-center">
	
	<form method="post" action="<?php echo e(route('admin.login.success')); ?>">
		<?php echo csrf_field(); ?>
		<input class="form-control" type="text" name="name" >
		<input class="form-control" type="password" name="password" >
		<input class="btn btn-success" type="submit" value="go">
	</form>

</div><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/admin/login.blade.php ENDPATH**/ ?>