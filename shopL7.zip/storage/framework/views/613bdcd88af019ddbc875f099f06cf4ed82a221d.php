<div class="row mt-5">
	<div class="col-md-3">
			<a href="categoria/computacion"><div class="card">
				<img src="https://w7.pngwing.com/pngs/977/520/png-transparent-knife-angle-grinder-product-design-grinding-lathe-knife-diamond-stone-computer-hardware.png" class="card-img-top" width="240" height="200">
				<div class="card-body">
					<p class="text-center">Computacion</p>
				</div>
			</div></a>
	</div>
	<div class="col-md-3">
			<a href=""><div class="card">
				<img src="https://img.favpng.com/14/17/15/screw-download-tool-png-favpng-gbnmQrrdkuSTLMnKjpyzXHtyQ_t.jpg" class="card-img-top" width="240" height="200">
				<div class="card-body">
					<p class="text-center">Ferreteria</p>
				</div>
			</div></a>
	</div>
	<div class="col-md-3">
			<a href=""><div class="card">
				<img src="http://mckinneydoor.com/wp-content/uploads/architetural-hardware-2.png" class="card-img-top" width="240" height="200">
				<div class="card-body">
					<p class="text-center">Repuestos</p>
				</div>
			</div></a>
	</div>
	<div class="col-md-3">
			<a href=""><div class="card">
				<img src="https://spectrumbrands.com/images/category-blocks/tileBanner_hhi.png" class="card-img-top" width="240" height="200">
				<div class="card-body">
					<p class="text-center">Usb</p>
				</div>
			</div></a>
	</div>
</div>

<div class="row mt-5">
	<div class="col-md-3">
			<a href=""><div class="card">
				<img src="https://w7.pngwing.com/pngs/977/520/png-transparent-knife-angle-grinder-product-design-grinding-lathe-knife-diamond-stone-computer-hardware.png" class="card-img-top" width="240" height="200">
				<div class="card-body">
					<p class="text-center">Computacion</p>
				</div>
			</div></a>
	</div>
	<div class="col-md-3">
			<a href=""><div class="card">
				<img src="https://img.favpng.com/14/17/15/screw-download-tool-png-favpng-gbnmQrrdkuSTLMnKjpyzXHtyQ_t.jpg" class="card-img-top" width="240" height="200">
				<div class="card-body">
					<p class="text-center">Ferreteria</p>
				</div>
			</div></a>
	</div>
	<div class="col-md-3">
			<a href=""><div class="card">
				<img src="http://mckinneydoor.com/wp-content/uploads/architetural-hardware-2.png" class="card-img-top" width="240" height="200">
				<div class="card-body">
					<p class="text-center">Repuestos</p>
				</div>
			</div></a>
	</div>
	<div class="col-md-3">
			<a href=""><div class="card">
				<img src="https://spectrumbrands.com/images/category-blocks/tileBanner_hhi.png" class="card-img-top" width="240" height="200">
				<div class="card-body">
					<p class="text-center">Usb</p>
				</div>
			</div></a>
	</div>
</div><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/layouts/parentcategorie.blade.php ENDPATH**/ ?>