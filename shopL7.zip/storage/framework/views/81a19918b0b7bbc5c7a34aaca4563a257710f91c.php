<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="stylesheet" type="text/css" href="css/fontawesome.min.css">
        <script src="https://kit.fontawesome.com/fd8d177af3.js" crossorigin="anonymous"></script>
 
  </head>
<body>  

        
     
         <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

         <div class="container container-height">
            
		<div class="mt-5 p-5">
			<table class="table">
				<thead class="thead-dark">
					<tr>
						<th scope="col">#</th>
						<th scope="col">nombre</th>
						<th scope="col">apellido</th>
						<th scope="col">cedula</th>
						<th scope="col">Estado</th>
						<th scope="col">ciudad</th>
						<th scope="col">phone</th>
						<th scope="col">email</th>
						<th scope="col">Metodo de envio</th>
						<th scope="col">Metodo de pago</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th scope="row"><?php echo e($loop->iteration); ?></th>
						<td><?php echo e($order->Name); ?></td>
						<td><?php echo e($order->Lastname); ?></td>
						<td><?php echo e($order->Cedula); ?></td>
						<td><?php echo e($order->Estado); ?></td>
						<td><?php echo e($order->city); ?></td>
						<td><?php echo e($order->phone); ?></td>
						<td><?php echo e($order->email); ?></td>
						<td><?php echo e($order->delivery); ?></td>
						<td><?php echo e($order->payment); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
				
					
		
				
				
			</div>
	       
         </div>
   
 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/admin/admin-success.blade.php ENDPATH**/ ?>