

<div class="mt-5">

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    <?php if($loop->first or $loop->index == 3): ?>
    <div class = "card-deck mt-3">
    <?php endif; ?>
        <div class="card" > 
            <div class="d-flex justify-content-end mr-2 mt-1 icon">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('admin.remove.product',$product->id)); ?>" class="btn btn-danger">x</a>
                <?php else: ?>
                
                    <a href="<?php echo e(route('product.addi', $product->id)); ?>" data-toggle="tooltip" data-placement="top" title="añadir al carrito" class="addi">
                        <i class="fas fa-cart-plus fa-2x"></i>
                    </a>
                <?php endif; ?>  
            </div>
            <div class="imgBx">
                 
                    <img src="<?php echo e(asset('storage/'.$product->pic)); ?>" >
                    
                
            </div>
            <div class="contentBx">
           
                <h3><?php echo e($product->tittle); ?></h3>
                <h2 class="price">$<?php echo e($product->price); ?></h2>
                <a href="<?php echo e(route('product.show',  Str::slug($product->tittle,'-'))); ?>" class="buy">Ver mas</a>        
            </div>
        </div>
    <?php if($loop->index == 2 or $loop->last): ?>
    </div>
    <?php endif; ?>

    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>          
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/product/indexshow.blade.php ENDPATH**/ ?>