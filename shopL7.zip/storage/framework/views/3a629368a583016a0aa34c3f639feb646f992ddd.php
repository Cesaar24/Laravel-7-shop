<li>
	<div class="d-flex bd-highlight">
		<div class="mr-auto p-2 bd-highlight categori">
			<a href="<?php echo e(route('categori.show',$ParentCategory->Name)); ?>"><?php echo e($ParentCategory->Name); ?></a>
		</div>
	
	

<?php if($ParentCategory->children != null): ?>
	
		<div class="p-2 bd-highlight">
			<a class="parent " data-toggle="collapse" href="#<?php echo e($ParentCategory->Name); ?>" role="button" aria-expanded="false" aria-controls="<?php echo e($ParentCategory->Name); ?>">
				+
			</a>	
		</div>
	</div>

	<div class="collapse" id="<?php echo e($ParentCategory->Name); ?>">
		<ul class="child">
			<?php echo $__env->renderEach('category.example',$ParentCategory->children,'ParentCategory'); ?>
		</ul>
	</div>
</li>

<?php else: ?>
</div>
</li>

<?php endif; ?><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/category/example.blade.php ENDPATH**/ ?>