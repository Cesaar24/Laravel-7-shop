<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="row">
          <div class="col-sm-4 text-center">
            <img src="default.png" width="90" height="90" class="d-block w-100" alt="default.png">
            <p >PRODUCTO SFSAF</p>
            <span>200.2$</span>
          </div>
          <div class="col-sm-4">
            <img src="default.png" width="90" height="90" class="d-block w-100" alt="default.png">
          </div>
          <div class="col-sm-4">
            <img src="default.png" width="90" height="90" class="d-block w-100" alt="default.png">
          </div>
      </div>
      
    </div>
    <div class="carousel-item">
       <div class="row">
          <div class="col-sm-4">
            <img src="default.png" width="90" height="90" class="d-block w-100" alt="default.png">
          </div>
          <div class="col-sm-4">
            <img src="default.png" width="90" height="90" class="d-block w-100" alt="default.png">
          </div>
          <div class="col-sm-4">
            <img src="default.png" width="90" height="90" class="d-block w-100" alt="default.png">
          </div>
      </div>
    </div>
    <div class="carousel-item">
       <div class="row">
          <div class="col-sm-4">
            <img src="default.png" width="90" height="90" class="d-block w-100" alt="default.png">
          </div>
          <div class="col-sm-4">
            <img src="default.png" width="90" height="90" class="d-block w-100" alt="default.png">
          </div>
          <div class="col-sm-4">
            <img src="default.png" width="90" height="90" class="d-block w-100" alt="default.png">
          </div>
      </div>
    </div>
  </div>




  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/layouts/carrusel.blade.php ENDPATH**/ ?>