
    
<div>
	<table class="table">
		<thead class="thead-dark">
			<tr>
				<th scope="col">#</th>
				<th scope="col">Nombre</th>
				<th scope="col">Cedula</th>
				<th scope="col">Phone</th>
				<th scope="col">Email</th>
				<th scope="col">Fecha</th>

			</tr>
		</thead>
		<tbody>
		<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
			<tr>
				<th scope="row"><?php echo e($order->id); ?> </th>
				<td><?php echo e($order->Name); ?></td>
				<td><?php echo e($order->Cedula); ?></td>
				<td><?php echo e($order->phone); ?></td>
				<td><?php echo e($order->email); ?></td>
				<td><?php echo e($order->created_at->format('d/m/Y')); ?></td>
				<td><a href="<?php echo e(route('order.show',$order->id)); ?>" class="btn btn-info">></a></td>
			</tr>
		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<div class="d-flex justify-content-center">
		
		<?php echo e($orders); ?>


	</div>
</div>


        
     
     
        


   
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/order/table.blade.php ENDPATH**/ ?>