<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>AE| Categoria <?php echo e($tag); ?></title>
		
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/side.css')); ?>">

        <script src="https://kit.fontawesome.com/fd8d177af3.js" crossorigin="anonymous"></script>
     
 	
  </head>
<body>  
 <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container container-height" >
       
         <section class="mt-5 pt-4">
         	<div class="row">
         		<div class="col-lg-3 side" >
         			<?php echo $__env->make('category.slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         		</div>
         		<div class="col-lg-9">
         			<h2 class="text-head mt-3" ><?php echo e($tag); ?></h2>
                    <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($loop->first or ($loop->iteration % 3) == 1): ?>
         			    <div class="row mt-5  " >
                    <?php endif; ?>
             				<div class="col-sm-4 text-center p-2 product-blur" >
                                <div class="d-flex justify-content-end mr-2 mt-1 icon">
                                    <?php if(auth()->guard()->check()): ?>
                                        <a href="<?php echo e(route('admin.remove.product',$Product->id)); ?>" class="btn btn-danger">x</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('product.addi',$Product->id)); ?>" data-toggle="tooltip" data-placement="top" title="añadir al carrito" >
                                            <i class="fas fa-cart-plus fa-2x"></i>
                                        </a>
                                    <?php endif; ?>  
                                </div>
                                <a href="<?php echo e(route('product.show',Str::slug($Product->tittle,'-'))); ?>" >
             					  <img src="<?php echo e(asset('storage/'.$Product->pic)); ?>" width="200px" height="200px" class="imgp">
             					  <p><?php echo e($Product->tittle); ?></p><span>$<?php echo e($Product->price); ?></span>
                                  <div class="my-auto">
                                    <button class="btn btn-cyan">ver mas</button> 
                                  </div>
             					</a>
             				</div>
         			<?php if( ($loop->iteration % 3) == 0): ?>   
                        </div>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         		</div>
         	</div>

         	
         </section>
 		 
    </div>	
 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(session('status')): ?>
  <div class="toast toast-status position-fixed bottom-0 right-0 " role="alert" aria-live="assertive" aria-atomic="true" data-delay="5000" >
    <div class="toast-header ">
      
      <i class="fas fa-check mr-auto"></i>
      <button type="button" class=" mb-1 close" data-dismiss="toast" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="toast-body">
     <?php echo e(session('status')); ?>

    </div>
  </div>
<?php endif; ?>

<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/js.js')); ?>" ></script>



</body>
</html>
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/category/show.blade.php ENDPATH**/ ?>