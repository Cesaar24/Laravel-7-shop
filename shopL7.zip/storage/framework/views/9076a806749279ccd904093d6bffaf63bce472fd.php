

<?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($loop->first or ($loop->iteration % 3) == 1): ?>
	<div class="row mt-5 p-5">
	<?php endif; ?>
		<div class="col-md-4 text-center p-2">
			<a href="<?php echo e(route('categori.show',$parent->Name)); ?>" style="text-decoration: none;">
			
				<img src="<?php echo e(asset('storage/'.$parent->pic)); ?>" width="240" height="200">

				<p style="text-transform: uppercase; font-family: Karla,sans-serif;"	><?php echo e($parent->Name); ?></p>
				
			</a>
		</div>

	<?php if( ($loop->iteration % 3) == 0): ?>	
	</div>
	<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/category/parentcategorie.blade.php ENDPATH**/ ?>