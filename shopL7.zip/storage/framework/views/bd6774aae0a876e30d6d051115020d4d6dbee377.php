<footer class=" text-white text-center text-lg-start mt-5 " >
  <!-- Grid container -->
  <div class="container p-4">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <h5 class="text-uppercase">Footer Content</h5>

        <p>
          Estamos para atenderte
		      021x-xxxxx :
          <span class="mr-1">
            <a href="#!" class="text-white"><img src="<?php echo e(asset('icon/whatsapp3.png')); ?>" width="75px" height="45px"> </a>
          </span>
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed t laborum.</p>
      </div>
     
      <!--Grid column-->
      <div class="col-lg-6 col-md-6 mb-4 mb-md-0">
        <h5 class="text-uppercase">Siguenos en nuestras redes sociales:</h5>
       
          <div class="social-red">
            
            <span class="mr-2">
              <a href="#!" class="text-white"><img src="<?php echo e(asset('icon/instagran.png')); ?>" width="45px" height="45px"> </a>
            </span >
            <span >
              <a href="#!" class="text-white"><img src="<?php echo e(asset('icon/facebook.png')); ?>" width="45px" height="45px"></a>
            </span>
          </div>
  
        
     </div>

    </div>
    <!--Grid row-->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-2 copyright" >
    © 2020 Copyright:
    <a class="text-white" href="https://mdbootstrap.com/">MIDOMINIO.com</a>
  </div>
  <!-- Copyright -->
</footer>
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/layouts/footer.blade.php ENDPATH**/ ?>