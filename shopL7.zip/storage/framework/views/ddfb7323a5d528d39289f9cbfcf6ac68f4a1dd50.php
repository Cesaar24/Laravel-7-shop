
<h1 class="text-head">Pedido <?php echo e($order->id); ?>:</h1>
<h2 class="mt-2">Datos del cliente:</h2>
<p>Nombre:<strong class="ml-2"><?php echo e($order->Name); ?></strong></p>
<p>Apellido:<strong class="ml-2"><?php echo e($order->Lastname); ?></strong></p>
<p>Cedula:<strong class="ml-2"><?php echo e($order->Cedula); ?></strong></p>
<p>Estado:<strong class="ml-2"><?php echo e($order->Estado); ?></strong></p>
<p>Ciudad:<strong class="ml-2"><?php echo e($order->city); ?></strong></p>
<p>Telefono:<strong class="ml-2"><?php echo e($order->phone); ?></strong></p>
<p>Correo:<strong class="ml-2"><?php echo e($order->email); ?></strong></p>
<p>Metodo de envio:<strong class="ml-2"><?php echo e($order->delivery); ?></strong></p>
<p>Metodo de pago:<strong class="ml-2"><?php echo e($order->payment); ?></strong></p>

<h2 class="mt-2">Productos del pedido <?php echo e($order->id); ?>:</h2>
<?php ($total = 0.0); ?>
<ul>
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li>
			<ul style="list-style: none">
				<li>
					<span>Producto:
					<strong class="ml-2 " ><a href="<?php echo e(route('product.show',$product->tittle)); ?>"><?php echo e($product->tittle); ?></a></strong></span> 
					<img src="<?php echo e(asset('storage/'.$product->pic)); ?>" width="50px" height="50px">
				</li>

				<li>
					<span>Precio: <?php echo e($product->price); ?>$</span>
				</li>

				<li>
					<span>Cantidad: <?php echo e($product->quantity); ?></span>
				</li>

				<li>
					<span>Subtotal: <?php echo e($product->price * $product->quantity); ?>$</span>
				</li>
			</ul>
		</li>
		<?php ($total = $total + ($product->price * $product->quantity)  ); ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<p>Total: <?php echo e($total); ?>$</p>
<div class="d-flex justify-content-end">
	<a href="<?php echo e(route('order.success',$order->id)); ?>" class="btn btn-cyan rounded-pill mr-2">Finalizar Pedido</a>
	<a href="<?php echo e(route('order.failed',$order->id)); ?>" class="btn btn-danger rounded-pill">Eliminar Pedido</a>
</div><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/order/show.blade.php ENDPATH**/ ?>