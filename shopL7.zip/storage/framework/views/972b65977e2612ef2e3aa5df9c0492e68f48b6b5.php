

<h3 class="mt-2">Categoria</h3>
<div class="mb-3">
<?php if(isset($categorys)): ?>

<?php for($i = count($categorys) - 1 ; $i >= 0 ; $i--): ?>
	<a href="<?php echo e(route('categori.show',$categorys[$i])); ?>" style="color: #88a;font-size: 15px"	 ><?php echo e($categorys[$i]); ?>/</a>

<?php endfor; ?>
<?php else: ?>
	<a href="<?php echo e(route('categori.show',$category)); ?>" ><?php echo e($category); ?></a>
<?php endif; ?>


</div>

<div class="row detail mt-5">
	<div class=" col-lg-7 ">
		<div class="imgBx">
			<img src="<?php echo e(asset('storage/'.$product->pic)); ?>">
		</div>
	</div>
	<div class=" col-lg-5 " id="formDetail">
		<div class="text-center">
			<h2 class="mt-4 "><?php echo e($product->tittle); ?></h2>
			<h3 class="mb-4 ">$<?php echo e($product->price); ?></h3>
			<h3>Descripcion:</h3>
			<p><?php echo e($product->description); ?></p>
		</div>

		
		<div class="mb-3">

			<?php if(isset($categorys)): ?>
			<?php for($i = count($categorys) - 1 ; $i >= 0 ; $i--): ?>
				<a href="<?php echo e(route('categori.show',$categorys[$i])); ?>" class="badge badge-primary"><?php echo e($categorys[$i]); ?></a>
			<?php endfor; ?>
			<?php else: ?>
				<a href="<?php echo e(route('categori.show',$category)); ?>" class="badge badge-primary"><?php echo e($category); ?></a>
			<?php endif; ?>
		</div>

		<form action="<?php echo e(route('product.add')); ?>" method="post" class="d-flex text-center flex-column " style="min-height: 200px;"> 
			
			<div class="form-inline">
				<label for="cant">Cantidad</label>
				<?php if($product->quantity > 0): ?>
					<input type="number" name="quantity" min="1" max="<?php echo e($product->quantity); ?>" value="1" class=" ml-2 form-control">	
					<span class="ml-auto" style="font-family: Karla,Sans serif;color: #111;font-size:18px;">
						stock <i class="fas fa-check mr-auto"></i>
					</span>
				<?php else: ?>
					<input type="number" name="quantity" min="1" max="<?php echo e($product->quantity); ?>" disabled value="1" class=" ml-2 form-control">
					<div class="ml-auto">
						<span style="font-family: Karla,Sans serif;color: #111;font-size:18px;" >stock:</span>
						<span style="font-family: Karla,Sans serif;color: #f11;font-size:20px;">Agotado</span>	
					</div>
					
				<?php endif; ?>
				
			</div>
			

			<div class="mt-auto mb-2">
			<?php if($product->quantity > 0): ?>
				<?php echo csrf_field(); ?>
				<input type="hidden" name="id" value="<?php echo e($product->id); ?>">
				<input type="submit" name="sub" class="btn btn-cyan btn-block rounded-pill"  value="Añadir al carrito">	
			<?php else: ?>
				<input type="submit" name="sub" class="btn btn-cyan btn-block rounded-pill" disabled value="Añadir al carrito">	
			<?php endif; ?>
			</div>
		</form>
		
	</div>
</div>
<div class="mt-5">
	<h2 class="text-head">Descripcion:</h2>
	<p class="pl-4"><?php echo e($product->description); ?></p>
</div>

<div class="mt-5">
	<h2 class="text-head mb-3">Productos Relacionados</h2>
	<?php echo $__env->make('layouts.carrusel-category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/product/detail.blade.php ENDPATH**/ ?>