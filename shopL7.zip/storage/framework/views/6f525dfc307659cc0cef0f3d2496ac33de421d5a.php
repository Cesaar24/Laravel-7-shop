<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/app.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/fontawesome.min.css">
        <script src="https://kit.fontawesome.com/fd8d177af3.js" crossorigin="anonymous"></script>
 
  </head>
<body>  


	<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="container container-height">
		<h1 class="mt-5 p-2">Finalize su compra</h1>
		<h2 class="mt-5 p-2 text-head">Detalles de su pedido</h2>

		<table class="table">
			<thead class="thead-dark">
				<tr>
					<th scope="col">Producto</th>
					<th scope="col">Subtotal</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($item->name); ?> <strong>x<?php echo e($item->quantity); ?></strong></td>
					<td><?php echo e($item->price * $item->quantity); ?>$</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><strong>Total</strong></td>
					<td class="total"><?php echo e(Cart::getTotal()); ?>$</td>
				</tr>
			</tbody>
		</table>
		<div class="d-flex justify-content-end">
			<a href="<?php echo e(route('cart.show')); ?>" class="btn btn-secondary rounded-pill">Ir al carrito</a>
		</div>
		<h2 class="mt-5 text-head">Detalles de Factura </h2>
	
		
		<form class="mt-3 pt-2" method="post" action="<?php echo e(route('check.submit')); ?>">
			<?php echo csrf_field(); ?>
			<div class="form-group row">
				
				<div class="col-sm-6">
					<label for="name" class="col-sm-2 col-form-label">Nombre</label>
				
					<input type="text" required class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">
					<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="alert alert-danger"><?php echo e($message); ?></div>
    				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				
				<div class="col-sm-6">
					<label for="LastName" class="col-sm-2 col-form-label">Apellido</label>
					<input type="text" required class="form-control" id="LastName" name="LastName" value="<?php echo e(old('LastName')); ?>">
					<?php $__errorArgs = ['LastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="alert alert-danger"><?php echo e($message); ?></div>
    				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>

			<div class="form-group row">
				
				<div class="col-sm-6">
					<label for="cedula" class="col-sm-2 col-form-label">Cedula</label>
					<input type="text" required class="form-control" id="cedula" name="cedula" value="<?php echo e(old('cedula')); ?>">
					<?php $__errorArgs = ['cedula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="alert alert-danger"><?php echo e($message); ?></div>
    				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

			</div>

			<div class="form-group row">
				<h5>Pais/Region: </h5>
				<h5><strong> Venezuela</strong></h5>
			</div>
			<div class="form-group row">
				<div class="col-sm-6">
					<label for="estado" class="col-sm-2 col-form-label">Estado</label>
					<input type="text" required class="form-control" id="estado" name="estado" value="<?php echo e(old('estado')); ?>">
					<?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="alert alert-danger"><?php echo e($message); ?></div>
    				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="col-sm-6">
					<label for="city" class="col-sm-2 col-form-label">Ciudad</label>
					<input type="text" required class="form-control" id="city" name="city" value="<?php echo e(old('city')); ?>">
					<?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="alert alert-danger"><?php echo e($message); ?></div>
    				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="form-group row">
				<div class="col-sm-6">
					<label for="phone" class="col-sm-2 col-form-label">Telefono</label>
					<input type="text" required class="form-control" id="phone" name="phone" value="<?php echo e(old('phone')); ?>">
					<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="alert alert-danger"><?php echo e($message); ?></div>
    				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="col-sm-6">
					<label for="email" class="col-sm-2 col-form-label">Email</label>
					<input type="email" required class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">
					<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="alert alert-danger"><?php echo e($message); ?></div>
    				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>

			<fieldset class="form-group row">
			<legend class="col-form-label col-sm-2 float-sm-left pt-0"  >Metodo de Entrega</legend>
				<div class="col-sm-10">
					<div class="form-check">
						<input class="form-check-input " type="radio" name="delivery" required id="gridRadios1" value="Retiro en Tienda" checked  >
						<label class="form-check-label" for="gridRadios1">
						Retiro en Tienda
						</label>
					</div>
					<div class="form-check">
						<input class="form-check-input" type="radio" name="delivery" required id="gridRadios2" value="Envio a ....">
						<label class="form-check-label" for="gridRadios2">
						Envio a ....  <strong>$1</strong>
						</label>
					</div>
					<div class="form-check ">
						<input class="form-check-input" type="radio" name="delivery" required id="gridRadios3" value="otro" >
						<label class="form-check-label" for="gridRadios3">
						otro ... <strong>$1</strong>
						</label>
					</div>
				</div>
			</fieldset>
			<fieldset class="form-group row">
				<legend class="col-form-label col-sm-2 float-sm-left pt-0" required >Metodo de Pago</legend>
				<div class="col-sm-10">
					<div class="form-check">
						<input class="form-check-input" type="radio" name="payment" id="gridRadios4" value="Pago en tienda" checked>
						<label class="form-check-label" for="gridRadios4">
						Pago en tienda
						</label>
					</div>
					<div class="form-check">
						<input class="form-check-input" type="radio" name="payment" id="gridRadios5" value="Transferencia Bancaria">
						<label class="form-check-label" for="gridRadios5">
						Transferencia Bancaria
						</label>
					</div>
				</div>
			</fieldset>
			<input type="submit" name="submit" class="btn btn-danger rounded-pill" value="Realizar Pedido" >
		</form>
		






	</div>
   
 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
<script type="text/javascript" src="js/app.js"></script>
<script type="text/javascript" src="<?php echo e(asset('js/js.js')); ?>" ></script>

</body>
</html>
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/order/input.blade.php ENDPATH**/ ?>