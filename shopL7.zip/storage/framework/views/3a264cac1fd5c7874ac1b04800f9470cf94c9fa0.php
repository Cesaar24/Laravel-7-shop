<?php $__env->startSection('title'); ?>
	404 no found
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1 class="text-center mt-5 pt-5">404 Not Found</h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions/views/404.blade.php ENDPATH**/ ?>