

        
     
     
        

         <div class="container container-height">
            
		<div class="mt-5 p-5">
			<table class="table">
				<thead class="thead-dark">
					<tr>
						<th scope="col">#</th>
						<th scope="col">nombre</th>
						<th scope="col">apellido</th>
						<th scope="col">cedula</th>
						<th scope="col">Estado</th>
						<th scope="col">ciudad</th>
						<th scope="col">phone</th>
						<th scope="col">email</th>
						<th scope="col">Metodo de envio</th>
						<th scope="col">Metodo de pago</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th scope="row"><?php echo e($loop->iteration); ?></th>
						<td><?php echo e($order->Name); ?></td>
						<td><?php echo e($order->Lastname); ?></td>
						<td><?php echo e($order->Cedula); ?></td>
						<td><?php echo e($order->Estado); ?></td>
						<td><?php echo e($order->city); ?></td>
						<td><?php echo e($order->phone); ?></td>
						<td><?php echo e($order->email); ?></td>
						<td><?php echo e($order->delivery); ?></td>
						<td><?php echo e($order->payment); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
				
					
		
				
				
			</div>
	       
         </div>
   
<?php /**PATH C:\Users\AN70N\Desktop\mi futuru\Laravel\shop\resources\views/admin/admin.blade.php ENDPATH**/ ?>