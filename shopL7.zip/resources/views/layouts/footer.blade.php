<footer class=" text-white text-center text-lg-start mt-5 " >
  <!-- Grid container -->
  <div class="container p-4">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <h5 class="text-uppercase">Footer Content</h5>
{{--     <form action="">
		      <div class="row">
		        <div class="col-auto mb-4 mb-md-0">
		          <p class="pt-2"><strong>SUSCRÍBETE</strong></p>
		        </div>

		        <div class="col-md-5 col-12 mb-4 mb-md-0">
		          <div class="form-outline mb-4">
		            <input type="email" id="form5Example2" class="form-control" />
		            <label class="form-label" for="form5Example2">Email address</label>
		          </div>
		        </div>

		        <div class="col-auto mb-4 mb-md-0">
		          <button type="submit" class="btn btn-success mb-4">Subscribe</button>
		        </div>
		      </div>
   			 </form> --}}
        <p>
          Estamos para atenderte
		      021x-xxxxx :
          <span class="mr-1">
            <a href="#!" class="text-white"><img src="{{asset('icon/whatsapp3.png')}}" width="75px" height="45px"> </a>
          </span>
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed t laborum.</p>
      </div>
     
      <!--Grid column-->
      <div class="col-lg-6 col-md-6 mb-4 mb-md-0">
        <h5 class="text-uppercase">Siguenos en nuestras redes sociales:</h5>
       
          <div class="social-red">
            
            <span class="mr-2">
              <a href="#!" class="text-white"><img src="{{asset('icon/instagran.png')}}" width="45px" height="45px"> </a>
            </span >
            <span >
              <a href="#!" class="text-white"><img src="{{asset('icon/facebook.png')}}" width="45px" height="45px"></a>
            </span>
          </div>
  {{--  --}}
        
     </div>

    </div>
    <!--Grid row-->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-2 copyright" >
    © 2020 Copyright:
    <a class="text-white" href="https://mdbootstrap.com/">MIDOMINIO.com</a>
  </div>
  <!-- Copyright -->
</footer>
